#
#f - исходный файл
#t - файл в который записать
#j - количество потоков
#
make
./main -f 1.pnm -t 1F.pnm -j 1
./main -f 2.pnm -t 2F.pnm -j 1
